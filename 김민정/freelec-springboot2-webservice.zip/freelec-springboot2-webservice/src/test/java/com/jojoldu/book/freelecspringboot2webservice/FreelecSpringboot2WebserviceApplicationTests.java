package com.jojoldu.book.freelecspringboot2webservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreelecSpringboot2WebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
